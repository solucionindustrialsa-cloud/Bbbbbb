import { NextResponse } from "next/server";
import { db } from "@/db";
import { storeConfig, products, paymentMethods, orders } from "@/db/schema";

export async function POST() {
  try {
    const existingProducts = await db.select().from(products).limit(1);
    const existingConfig = await db.select().from(storeConfig).limit(1);
    const existingPay = await db.select().from(paymentMethods).limit(1);
    const existingOrders = await db.select().from(orders).limit(1);

    if (existingConfig.length === 0) {
      await db.insert(storeConfig).values({
        storeName: "caprichitos_cosas_lindas",
        tagline: "Bolsos, mochilas y vasos térmicos con amor 💗",
        logoImage: "",
        whatsappNumber: "5491123456789",
        instagram: "caprichitos_cosas_lindas",
        address: "Argentina · Envíos a todo el país",
        announcement: "✨ Envíos a todo el país · Pedidos por WhatsApp ✨",
        heroTitle: "Cosas lindas que te hacen feliz",
        heroSubtitle: "Bolsos, mochilas y vasos térmicos únicos, elegidos con amor para vos.",
      });
    }

    if (existingPay.length === 0) {
      await db.insert(paymentMethods).values([
        { name: "Efectivo", details: "Pagás al recibir o retirar", instructions: "Coordinamos por WhatsApp", enabled: true, sortOrder: 0 },
        { name: "Transferencia bancaria", details: "Alias: CAPRICHITOS.MP · CBU a coordinar", instructions: "Enviá el comprobante por WhatsApp", enabled: true, sortOrder: 1 },
        { name: "Mercado Pago", details: "Link de pago / QR", instructions: "Te enviamos el link por WhatsApp", enabled: true, sortOrder: 2 },
        { name: "Tarjeta de crédito / débito", details: "Visa · Master · Naranja", instructions: "Link de pago seguro", enabled: true, sortOrder: 3 },
      ]);
    }

    if (existingProducts.length === 0) {
      await db.insert(products).values([
        { name: "Bolso Rosa Acolchado", description: "Bolso acolchado color rosa pastel con cadena dorada. Ideal para salidas, súper canchero y combinable.", price: 28999, category: "bolsos", image: "/images/bolso-rosa.jpg", stock: 12, featured: true, isActive: true },
        { name: "Mochila Mini Coquette", description: "Mini mochila rosa con moño y pompón. Entra celu, bille y maquillaje. ¡La más pedida!", price: 24999, category: "mochilas", image: "/images/mochila-rosa.jpg", stock: 15, featured: true, isActive: true },
        { name: "Vaso Térmico Corazón", description: "Vaso térmico rosa de 750ml con sorbete. Mantiene frío 12hs y calor 8hs.", price: 15999, category: "vasos", image: "/images/vaso-rosa.jpg", stock: 20, featured: true, isActive: true },
        { name: "Tote Corazones", description: "Tote bag blanca con corazones rosas. Tela reforzada, ideal para todos los días.", price: 12999, category: "bolsos", image: "/images/tote-corazones.jpg", stock: 18, featured: false, isActive: true },
        { name: "Mochila Blanca Gold", description: "Mochila blanca con cierres dorados. Elegante, amplia y cómoda para el día a día.", price: 32999, category: "mochilas", image: "/images/mochila-blanca.jpg", stock: 8, featured: true, isActive: true },
        { name: "Vaso Térmico Blanco Floral", description: "Botella térmica blanca con diseño floral y moño. 1L, acero inoxidable.", price: 18999, category: "vasos", image: "/images/vaso-blanco.jpg", stock: 14, featured: false, isActive: true },
        { name: "Bandolera Perlas", description: "Bandolera rosa con correa de perlas. Toque coquette para tus looks.", price: 19999, category: "bolsos", image: "/images/bolso-bandolera.jpg", stock: 10, featured: false, isActive: true },
        { name: "Set Caprichito x3", description: "Combo: mini bolso + vaso térmico + tote. ¡Para regalar o regalarte!", price: 49999, category: "combos", image: "/images/hero-flatlay.jpg", stock: 6, featured: true, isActive: true },
      ]);
    }

    if (existingOrders.length === 0) {
      const now = Date.now();
      const day = 86400000;
      const demo = [
        { n: "Sofía Martín", p: "1123456789", items: [{ productId: 1, name: "Bolso Rosa Acolchado", price: 28999, qty: 1 }], total: 28999, pay: "Transferencia bancaria", days: 0 },
        { n: "Valentina Ruiz", p: "1134567890", items: [{ productId: 3, name: "Vaso Térmico Corazón", price: 15999, qty: 2 }], total: 31998, pay: "Mercado Pago", days: 1 },
        { n: "Camila Torres", p: "1145678901", items: [{ productId: 2, name: "Mochila Mini Coquette", price: 24999, qty: 1 }], total: 24999, pay: "Efectivo", days: 2 },
        { n: "Martina López", p: "1156789012", items: [{ productId: 5, name: "Mochila Blanca Gold", price: 32999, qty: 1 }], total: 32999, pay: "Tarjeta de crédito / débito", days: 3 },
        { n: "Juana Pérez", p: "1167890123", items: [{ productId: 4, name: "Tote Corazones", price: 12999, qty: 1 }, { productId: 3, name: "Vaso Térmico Corazón", price: 15999, qty: 1 }], total: 28998, pay: "Transferencia bancaria", days: 5 },
        { n: "Emma García", p: "1178901234", items: [{ productId: 8, name: "Set Caprichito x3", price: 49999, qty: 1 }], total: 49999, pay: "Mercado Pago", days: 6 },
        { n: "Olivia Sosa", p: "1189012345", items: [{ productId: 7, name: "Bandolera Perlas", price: 19999, qty: 1 }], total: 19999, pay: "Efectivo", days: 8 },
        { n: "Mía Fernández", p: "1190123456", items: [{ productId: 6, name: "Vaso Térmico Blanco Floral", price: 18999, qty: 2 }], total: 37998, pay: "Transferencia bancaria", days: 10 },
        { n: "Sofía Martín", p: "1123456789", items: [{ productId: 2, name: "Mochila Mini Coquette", price: 24999, qty: 1 }], total: 24999, pay: "Mercado Pago", days: 11 },
        { n: "Isabella Díaz", p: "1101234567", items: [{ productId: 1, name: "Bolso Rosa Acolchado", price: 28999, qty: 1 }], total: 28999, pay: "Efectivo", days: 12 },
      ];
      for (const d of demo) {
        await db.insert(orders).values({
          customerName: d.n,
          customerPhone: d.p,
          customerAddress: "CABA",
          items: d.items,
          total: d.total,
          paymentMethod: d.pay,
          status: d.days > 4 ? "entregado" : d.days > 1 ? "en preparación" : "pendiente",
          createdAt: new Date(now - d.days * day),
        });
      }
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Seed error" }, { status: 500 });
  }
}

export async function GET() {
  return POST();
}

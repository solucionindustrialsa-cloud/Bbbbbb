import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(products).orderBy(desc(products.createdAt));
    return NextResponse.json(rows);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error productos" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const inserted = await db.insert(products).values({
      name: body.name,
      description: body.description ?? "",
      price: Number(body.price) || 0,
      category: body.category ?? "bolsos",
      image: body.image ?? "",
      stock: Number(body.stock) ?? 10,
      featured: Boolean(body.featured),
      isActive: body.isActive !== false,
    }).returning();
    return NextResponse.json(inserted[0]);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error al crear producto" }, { status: 500 });
  }
}

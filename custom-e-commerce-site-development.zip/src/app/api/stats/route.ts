import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products } from "@/db/schema";

export async function GET() {
  try {
    const allOrders = await db.select().from(orders).limit(500);
    const allProducts = await db.select().from(products).limit(200);

    const totalRevenue = allOrders.reduce((s, o) => s + (o.total ?? 0), 0);
    const totalOrders = allOrders.length;
    const uniqueClients = new Set(allOrders.map((o) => (o.customerPhone || o.customerName).toLowerCase().trim())).size;
    const avgTicket = totalOrders ? Math.round(totalRevenue / totalOrders) : 0;

    // ventas por día (últimos 14 días)
    const days: { fecha: string; ventas: number; pedidos: number }[] = [];
    const map = new Map<string, { ventas: number; pedidos: number }>();
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      map.set(key, { ventas: 0, pedidos: 0 });
    }
    for (const o of allOrders) {
      const key = o.createdAt ? new Date(o.createdAt).toISOString().slice(0, 10) : "";
      if (map.has(key)) {
        const v = map.get(key)!;
        v.ventas += o.total ?? 0;
        v.pedidos += 1;
      }
    }
    for (const [fecha, v] of map) {
      const d = new Date(fecha + "T12:00:00");
      const label = d.toLocaleDateString("es-AR", { day: "2-digit", month: "2-digit" });
      days.push({ fecha: label, ventas: v.ventas, pedidos: v.pedidos });
    }

    // por categoría
    const prodById = new Map(allProducts.map((p) => [p.id, p]));
    const catMap = new Map<string, number>();
    for (const o of allOrders) {
      const items = (o.items ?? []) as { productId: number; price: number; qty: number }[];
      for (const it of items) {
        const p = prodById.get(Number(it.productId));
        const cat = p?.category ?? "otros";
        catMap.set(cat, (catMap.get(cat) ?? 0) + Number(it.price) * Number(it.qty));
      }
    }
    const porCategoria = [...catMap.entries()].map(([name, value]) => ({ name, value }));
    if (porCategoria.length === 0) {
      // fallback por stock de productos para que el gráfico no esté vacío
      const fallback = new Map<string, number>();
      for (const p of allProducts) {
        fallback.set(p.category, (fallback.get(p.category) ?? 0) + 1);
      }
      for (const [name, value] of fallback) porCategoria.push({ name, value });
    }

    // por método de pago
    const payMap = new Map<string, number>();
    for (const o of allOrders) {
      payMap.set(o.paymentMethod ?? "WhatsApp", (payMap.get(o.paymentMethod ?? "WhatsApp") ?? 0) + 1);
    }
    const porPago = [...payMap.entries()].map(([name, value]) => ({ name, value }));

    // top productos
    const topMap = new Map<string, { name: string; qty: number; revenue: number }>();
    for (const o of allOrders) {
      const items = (o.items ?? []) as { productId: number; name: string; price: number; qty: number }[];
      for (const it of items) {
        const k = it.name;
        const prev = topMap.get(k) ?? { name: k, qty: 0, revenue: 0 };
        prev.qty += Number(it.qty);
        prev.revenue += Number(it.price) * Number(it.qty);
        topMap.set(k, prev);
      }
    }
    const topProductos = [...topMap.values()].sort((a, b) => b.qty - a.qty).slice(0, 5);

    // clientes recientes
    const clientMap = new Map<string, { name: string; phone: string; pedidos: number; gastado: number; ultima: string }>();
    for (const o of allOrders) {
      const key = (o.customerPhone || o.customerName).toLowerCase();
      const prev = clientMap.get(key) ?? { name: o.customerName, phone: o.customerPhone ?? "", pedidos: 0, gastado: 0, ultima: "" };
      prev.pedidos += 1;
      prev.gastado += o.total ?? 0;
      prev.ultima = o.createdAt ? new Date(o.createdAt).toLocaleDateString("es-AR") : "";
      prev.name = o.customerName;
      clientMap.set(key, prev);
    }
    const clientes = [...clientMap.values()].sort((a, b) => b.gastado - a.gastado).slice(0, 10);

    // estado pedidos
    const statusMap = new Map<string, number>();
    for (const o of allOrders) statusMap.set(o.status, (statusMap.get(o.status) ?? 0) + 1);
    const porEstado = [...statusMap.entries()].map(([name, value]) => ({ name, value }));

    return NextResponse.json({
      totalRevenue, totalOrders, uniqueClients, avgTicket,
      porDia: days, porCategoria, porPago, topProductos, clientes, porEstado,
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error stats" }, { status: 500 });
  }
}

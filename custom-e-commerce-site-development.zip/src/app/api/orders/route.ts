import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(200);
    return NextResponse.json(rows);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error pedidos" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const items = Array.isArray(body.items) ? body.items : [];
    if (items.length === 0) {
      return NextResponse.json({ error: "Carrito vacío" }, { status: 400 });
    }
    const total = items.reduce((s: number, it: { price: number; qty: number }) => s + Number(it.price) * Number(it.qty), 0);
    const inserted = await db.insert(orders).values({
      customerName: body.customerName ?? "Cliente",
      customerPhone: body.customerPhone ?? "",
      customerAddress: body.customerAddress ?? "",
      customerNotes: body.customerNotes ?? "",
      items,
      total,
      paymentMethod: body.paymentMethod ?? "WhatsApp",
      status: "pendiente",
    }).returning();

    // descontar stock
    for (const it of items) {
      try {
        if (it.productId) {
          const prow = await db.select().from(products).where(eq(products.id, Number(it.productId))).limit(1);
          if (prow[0]) {
            const newStock = Math.max(0, (prow[0].stock ?? 0) - Number(it.qty));
            await db.update(products).set({ stock: newStock }).where(eq(products.id, Number(it.productId)));
          }
        }
      } catch { /* ignore */ }
    }

    return NextResponse.json(inserted[0]);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error al crear pedido" }, { status: 500 });
  }
}

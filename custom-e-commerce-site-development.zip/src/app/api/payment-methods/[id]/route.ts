import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { paymentMethods } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const updated = await db.update(paymentMethods).set({
      name: body.name,
      details: body.details ?? "",
      instructions: body.instructions ?? "",
      enabled: body.enabled !== false,
      sortOrder: Number(body.sortOrder) || 0,
    }).where(eq(paymentMethods.id, Number(id))).returning();
    if (!updated[0]) return NextResponse.json({ error: "No encontrado" }, { status: 404 });
    return NextResponse.json(updated[0]);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(paymentMethods).where(eq(paymentMethods.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error al eliminar" }, { status: 500 });
  }
}

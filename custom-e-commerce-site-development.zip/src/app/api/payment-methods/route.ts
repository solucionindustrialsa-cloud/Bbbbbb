import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { paymentMethods } from "@/db/schema";
import { asc } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(paymentMethods).orderBy(asc(paymentMethods.sortOrder));
    return NextResponse.json(rows);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error pagos" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const inserted = await db.insert(paymentMethods).values({
      name: body.name,
      details: body.details ?? "",
      instructions: body.instructions ?? "",
      enabled: body.enabled !== false,
      sortOrder: Number(body.sortOrder) || 0,
    }).returning();
    return NextResponse.json(inserted[0]);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Error al crear medio de pago" }, { status: 500 });
  }
}
